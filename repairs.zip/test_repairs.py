import sys,unittest,json
from pathlib import Path
from unittest.mock import Mock,patch
from urllib.error import HTTPError
sys.path.insert(0,str(Path(__file__).parent/"collector"))
from source_adapters import Reader,collect_counted,PartialListing
import public_feeds

class Repairs(unittest.TestCase):
    def test_moving_count_is_partial_not_complete(self):
        reader=Mock(base="https://careers.unesco.org/",host="careers.unesco.org")
        parser=Mock(side_effect=[
            ([{"external_id":"1"}],"https://careers.unesco.org/page2",2),
            ([{"external_id":"2"}],None,3)])
        with self.assertRaises(PartialListing) as result:
            collect_counted(reader,parser,allow_moving=True)
        self.assertEqual(len(result.exception.rows),2)

    def test_validated_pages_survive_later_http_failure(self):
        reader=Mock(base="https://api.smartrecruiters.com/v1/companies/Test/postings")
        reader.get.side_effect=['{}',HTTPError(reader.base,503,"Unavailable",{},None)]
        with patch.object(public_feeds,"smart_page",return_value=([{"external_id":"1"}],["1"],2)):
            with self.assertRaises(PartialListing) as result:
                public_feeds.collect_smart(reader,"Test")
        self.assertEqual(result.exception.rows,[{"external_id":"1"}])

    @patch("source_adapters.time.sleep")
    def test_known_api_400_retries_bounded(self,_):
        reader=Reader("https://api.smartrecruiters.com/v1/companies/Test/postings")
        reader.opener=Mock()
        reader.opener.open.side_effect=HTTPError(reader.base,400,"Bad request",{},None)
        with self.assertRaises(HTTPError):reader.get(reader.base)
        self.assertEqual(reader.opener.open.call_count,3)

    @patch("source_adapters.time.sleep")
    def test_other_host_400_not_retried(self,_):
        reader=Reader("https://careers.unesco.org/")
        reader.opener=Mock()
        reader.opener.open.side_effect=HTTPError(reader.base,400,"Bad request",{},None)
        with self.assertRaises(HTTPError):reader.get(reader.base)
        self.assertEqual(reader.opener.open.call_count,1)

if __name__=="__main__":unittest.main()
