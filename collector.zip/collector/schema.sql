PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS organizations(id INTEGER PRIMARY KEY,name TEXT UNIQUE NOT NULL,sector TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sources(id INTEGER PRIMARY KEY,organization_id INTEGER REFERENCES organizations(id),url TEXT UNIQUE NOT NULL,status TEXT NOT NULL,checked_on TEXT NOT NULL,attribution TEXT NOT NULL,notes TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS jobs(
 id INTEGER PRIMARY KEY,source_id INTEGER NOT NULL REFERENCES sources(id),external_id TEXT NOT NULL,
 title TEXT NOT NULL,location TEXT NOT NULL,work_mode TEXT NOT NULL DEFAULT 'unknown',
 url TEXT,posted_on TEXT,deadline TEXT,deadline_raw TEXT,closed INTEGER NOT NULL DEFAULT 0,
 is_demo INTEGER NOT NULL DEFAULT 0,requirements_complete INTEGER NOT NULL DEFAULT 0,
 UNIQUE(source_id,external_id));
CREATE TABLE IF NOT EXISTS requirements(id INTEGER PRIMARY KEY,job_id INTEGER REFERENCES jobs(id),field TEXT NOT NULL,operator TEXT NOT NULL,value TEXT NOT NULL,evidence TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS compensation(job_id INTEGER PRIMARY KEY REFERENCES jobs(id),minimum REAL,maximum REAL,currency TEXT,period TEXT,basis TEXT,evidence TEXT);
CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY,job_id INTEGER REFERENCES jobs(id),status TEXT NOT NULL,reviewed_at TEXT NOT NULL,expires_at TEXT NOT NULL,reviewer TEXT NOT NULL,evidence_url TEXT,notes TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS saved_jobs(job_id INTEGER PRIMARY KEY REFERENCES jobs(id),saved_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS review_job ON reviews(job_id,id);
CREATE INDEX IF NOT EXISTS job_deadline ON jobs(deadline);
PRAGMA user_version=1;
CREATE TABLE IF NOT EXISTS collected_jobs(
 job_id INTEGER PRIMARY KEY REFERENCES jobs(id),board TEXT NOT NULL,
 description TEXT NOT NULL,source_updated_at TEXT,first_seen TEXT NOT NULL,last_seen TEXT NOT NULL,
 content_hash TEXT NOT NULL,missing_count INTEGER NOT NULL DEFAULT 0,
 availability TEXT NOT NULL DEFAULT 'listed',last_missing_at TEXT);
CREATE TABLE IF NOT EXISTS job_revisions(
 id INTEGER PRIMARY KEY,job_id INTEGER REFERENCES jobs(id),observed_at TEXT NOT NULL,
 change_type TEXT NOT NULL,previous_json TEXT,new_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sync_runs(
 id INTEGER PRIMARY KEY,board TEXT NOT NULL,started_at TEXT NOT NULL,finished_at TEXT NOT NULL,
 status TEXT NOT NULL,fetched INTEGER NOT NULL DEFAULT 0,added INTEGER NOT NULL DEFAULT 0,
 changed INTEGER NOT NULL DEFAULT 0,removed INTEGER NOT NULL DEFAULT 0,error TEXT);
CREATE TABLE IF NOT EXISTS sync_lock(id INTEGER PRIMARY KEY CHECK(id=1),owner TEXT,expires_at TEXT);
CREATE TABLE IF NOT EXISTS sync_settings(id INTEGER PRIMARY KEY CHECK(id=1),enabled INTEGER NOT NULL);
INSERT OR IGNORE INTO sync_settings VALUES(1,1);
