"""Conservative search aids, never eligibility determinations."""
import json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
COUNTRIES=json.loads((ROOT/"data/countries.json").read_text(encoding="utf-8-sig"))
NAMES={x["name"].casefold():x["name"] for x in COUNTRIES}
NAMES.update({"uk":"United Kingdom","usa":"United States","united states of america":"United States","south korea":"South Korea","vietnam":"Vietnam","tÃ¼rkiye":"TÃ¼rkiye"})
LEVELS=[("mid",r"\b(?:mid[- ]level|intermediate)\b"),("executive",r"\b(?:CEO|CFO|COO|CTO|CIO|CHRO|president|vice president|VP|chief executive|chief financial|chief operating|chief technology)\b"),("internship",r"\b(?:intern|internship|apprentice|apprenticeship)\b"),("director",r"\b(?:director|head of)\b"),("manager",r"\b(?:manager|supervisor)\b"),("senior",r"\b(?:senior|sr\.?|lead|principal|staff engineer)\b"),("entry",r"\b(?:junior|entry[- ]level|graduate|trainee)\b")]
def classify(j):
    level=next((name for name,pattern in LEVELS if re.search(pattern,j["title"],re.I)),"unknown")
    # Country names must occupy a complete location segment; do not guess from cities.
    parts=[re.sub(r"^remote(?: in)?[ -]+", "", x.rsplit(",",1)[-1].strip(),flags=re.I) for x in re.split(r"[;/|]|\s+[\u2013\u2014]\s+",j["location"])]
    countries=sorted({NAMES[x.strip().casefold()] for x in parts if x.strip().casefold() in NAMES})
    board=(j.get("collection") or {}).get("board")
    if board in ("ny-state","sf-government"):countries=["United States"]
    if board in ("bd-teletalk","icddrb"):countries=["Bangladesh"]
    industry=FEEDS.get(board,{}).get("industry","Not classified")
    return dict(career_level=level,career_level_basis="Title estimate; check original notice" if level!="unknown" else "Not classified",countries=countries,industry=industry)
FEEDS={f["board"]:f for f in json.loads((ROOT/"data/feeds.json").read_text())}
