"""Read-only public job-board collection. No accounts, application POSTs or AI calls."""
import argparse
from contextlib import closing
import hashlib
import html
from html.parser import HTMLParser
import json
import re
import time
import uuid
from urllib.error import HTTPError, URLError
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.parse import urlsplit
import app
import source_adapters
import public_feeds

INTERVAL_HOURS = 6
FRESH_HOURS = 24
MAX_BYTES = 15_000_000

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise ValueError("Unexpected API redirect; manual review required")

class PlainText(HTMLParser):
    def __init__(self):
        super().__init__(); self.parts=[]; self.skip=0
    def handle_starttag(self, tag, attrs):
        if tag in ("script","style"): self.skip+=1
        if tag in ("p","li","br","div","h1","h2","h3"): self.parts.append("\n")
    def handle_endtag(self, tag):
        if tag in ("script","style"): self.skip=max(0,self.skip-1)
    def handle_data(self,data):
        if not self.skip: self.parts.append(data)

def plain(text):
    if not isinstance(text,str) or len(text)>1_000_000: raise ValueError("Invalid description")
    parser=PlainText(); parser.feed(html.unescape(text))
    return re.sub(r"\n\s*\n+","\n\n","".join(parser.parts)).strip()

def feeds():
    data=json.loads((app.ROOT/"data"/"feeds.json").read_text())
    for f in data:
        if not re.fullmatch(r"[a-z0-9-]{1,60}",f["board"]): raise ValueError("Invalid board token")
    return data

def fetch(board):
    if board in public_feeds.BASES:return public_feeds.collect(board)
    if board in source_adapters.PAGES:
        return source_adapters.collect(board)
    # The destination is fixed, not a URL supplied by a website or API record.
    url=f"https://boards-api.greenhouse.io/v1/boards/{board}/jobs?content=true"
    opener=build_opener(NoRedirect)
    for attempt in range(2):
        try:
            req=Request(url,headers={"User-Agent":"AtlasPrivateJobs/3.0 (public job board reader)","Accept":"application/json"})
            with opener.open(req,timeout=30) as response:
                raw=response.read(MAX_BYTES+1)
                if len(raw)>MAX_BYTES: raise ValueError("Feed exceeds safe size limit")
                return json.loads(raw)
        except HTTPError as e:
            if attempt or e.code not in (429,500,502,503,504): raise
            wait=e.headers.get("Retry-After","2")
            if not wait.isdigit() or int(wait)>10: raise
            time.sleep(max(1,int(wait)))
        except (URLError,TimeoutError):
            if attempt: raise
            time.sleep(2)

def normalized(payload,board):
    if board in source_adapters.PAGES or board in public_feeds.BASES:
        if not isinstance(payload,dict) or not isinstance(payload.get("atlas_rows"),list) or payload.get("total")!=len(payload["atlas_rows"]):
            raise ValueError("Invalid official listing snapshot")
        return payload["atlas_rows"],payload["total"]
    if not isinstance(payload,dict) or not isinstance(payload.get("jobs"),list):
        raise ValueError("Invalid feed schema; existing jobs preserved")
    rows=payload["jobs"]
    total=payload.get("meta",{}).get("total")
    if type(total) is not int or total!=len(rows) or len(rows)>10000:
        raise ValueError("Incomplete feed; existing jobs preserved")
    result=[]; seen=set()
    for j in rows:
        if not isinstance(j,dict) or type(j.get("id")) is not int or j["id"] in seen:
            raise ValueError("Invalid or duplicate job ID")
        seen.add(j["id"])
        # Greenhouse prospect/talent-pool posts are not current vacancies.
        if j.get("internal_job_id") is None: continue
        title=j.get("title")
        if not isinstance(title,str) or not title.strip(): raise ValueError("Missing title")
        url=j.get("absolute_url","")
        u=urlsplit(url)
        normal_url=u.hostname in ("job-boards.greenhouse.io","boards.greenhouse.io") and u.path.startswith("/"+board+"/jobs/")
        from urllib.parse import parse_qs
        oaf_url=board=="oneacrefund" and u.hostname=="oneacrefund.org" and u.path=="/vacancies/" and parse_qs(u.query).get("gh_jid")==[str(j["id"])]
        if u.scheme!="https" or not (normal_url or oaf_url) or u.username:
            raise ValueError("Unexpected vacancy destination")
        location=j.get("location",{}).get("name") or "Not stated"
        if not isinstance(location,str): raise ValueError("Invalid location")
        raw_deadline=j.get("application_deadline")
        deadline=None
        if raw_deadline:
            try: deadline=app.instant(raw_deadline).isoformat()
            except (ValueError,TypeError): pass
        published=j.get("first_published")
        posted=None
        if published:
            try: posted=app.instant(published).date().isoformat()
            except (ValueError,TypeError): pass
        mode=source_adapters.mode(location)
        result.append(dict(external_id=str(j["id"]),title=title.strip(),location=location,
            work_mode=mode,url=url,posted_on=posted,deadline=deadline,
            deadline_raw=raw_deadline or "Not supplied in structured feed; check official notice",
            description=plain(j.get("content","")),source_updated_at=j.get("updated_at")))
    return result,len(rows)

def register_source(db,f):
    db.execute("INSERT OR IGNORE INTO organizations(name,sector) VALUES(?,?)",(f["name"],f["sector"]))
    oid=db.execute("SELECT id FROM organizations WHERE name=?",(f["name"],)).fetchone()[0]
    url=f.get("source_url") or "https://job-boards.greenhouse.io/"+f["board"]
    db.execute("""INSERT OR IGNORE INTO sources(organization_id,url,status,checked_on,attribution,notes)
        VALUES(?,?,'portal_confirmed',?,?,?)""",(oid,url,f["relationship_checked_on"],f["name"],f["relationship_evidence"]))
    db.execute("UPDATE sources SET status='portal_confirmed',checked_on=?,notes=? WHERE url=?",
        (f["relationship_checked_on"],f["relationship_evidence"],url))
    return db.execute("SELECT id FROM sources WHERE url=?",(url,)).fetchone()[0]

def apply_snapshot(db,f,rows,stamp,complete=True):
    """One transaction for a completely validated board. Never deletes vacancies."""
    added=changed=removed=0
    with db:
        source=register_source(db,f)
        ids=[]
        for j in rows:
            encoded=json.dumps(j,sort_keys=True,ensure_ascii=False)
            digest=hashlib.sha256(encoded.encode()).hexdigest()
            old=db.execute("""SELECT j.*,c.content_hash,c.description,c.source_updated_at,c.availability
                FROM jobs j LEFT JOIN collected_jobs c ON j.id=c.job_id
                WHERE source_id=? AND external_id=?""",(source,j["external_id"])).fetchone()
            if old:
                jid=old["id"]
                different=old["content_hash"]!=digest
                change="updated" if different else "reappeared" if old["availability"]!="listed" else None
                if different:
                    db.execute("""UPDATE jobs SET title=?,location=?,work_mode=?,url=?,posted_on=?,deadline=?,deadline_raw=? WHERE id=?""",
                        tuple(j[k] for k in ("title","location","work_mode","url","posted_on","deadline","deadline_raw"))+(jid,))
                    # A changed notice invalidates old interpretations; preserve them for audit.
                    db.execute("""INSERT INTO reviews(job_id,status,reviewed_at,expires_at,reviewer,evidence_url,notes)
                        VALUES(?,'needs_review',?,?,?,?,?)""",(jid,stamp,(app.instant(stamp)+app.timedelta(days=1)).isoformat(),"Atlas collector",j["url"],"Employer notice changed; review eligibility and compensation again."))
                    changed+=1
            else:
                cur=db.execute("""INSERT INTO jobs(source_id,external_id,title,location,work_mode,url,posted_on,deadline,deadline_raw)
                    VALUES(?,?,?,?,?,?,?,?,?)""",(source,)+tuple(j[k] for k in ("external_id","title","location","work_mode","url","posted_on","deadline","deadline_raw")))
                jid=cur.lastrowid; added+=1; change="new"
            ids.append(jid)
            if change:
                previous=dict(old) if old else None
                if old:
                    previous["requirements"]=[dict(r) for r in db.execute("SELECT * FROM requirements WHERE job_id=?",(jid,))]
                    salary=db.execute("SELECT * FROM compensation WHERE job_id=?",(jid,)).fetchone()
                    previous["salary"]=dict(salary) if salary else None
                    if different:
                        db.execute("DELETE FROM requirements WHERE job_id=?",(jid,))
                        db.execute("DELETE FROM compensation WHERE job_id=?",(jid,))
                        db.execute("UPDATE jobs SET requirements_complete=0 WHERE id=?",(jid,))
                db.execute("INSERT INTO job_revisions(job_id,observed_at,change_type,previous_json,new_json) VALUES(?,?,?,?,?)",
                    (jid,stamp,change,json.dumps(previous,ensure_ascii=False) if previous else None,encoded))
            db.execute("""INSERT INTO collected_jobs(job_id,board,description,source_updated_at,first_seen,last_seen,content_hash)
                VALUES(?,?,?,?,?,?,?) ON CONFLICT(job_id) DO UPDATE SET
                description=excluded.description,source_updated_at=excluded.source_updated_at,last_seen=excluded.last_seen,
                content_hash=excluded.content_hash,missing_count=0,availability='listed',last_missing_at=NULL""",
                (jid,f["board"],j["description"],j["source_updated_at"],stamp,stamp,digest))
        seen=set(ids)
        for c in db.execute("SELECT * FROM collected_jobs WHERE board=?",(f["board"],)).fetchall() if complete else []:
            if c["job_id"] in seen: continue
            # Repeated immediate runs cannot manufacture a second absence confirmation.
            if c["last_missing_at"] and app.instant(stamp)-app.instant(c["last_missing_at"])<app.timedelta(hours=INTERVAL_HOURS): continue
            count=c["missing_count"]+1
            state="removed_from_feed" if count>=2 else "not_seen"
            db.execute("UPDATE collected_jobs SET missing_count=?,availability=?,last_missing_at=? WHERE job_id=?",(count,state,stamp,c["job_id"]))
            if c["availability"]!=state:
                removed+=1
                db.execute("INSERT INTO job_revisions(job_id,observed_at,change_type,previous_json,new_json) VALUES(?,?,?,?,?)",
                    (c["job_id"],stamp,state,json.dumps(dict(c)),json.dumps({"availability":state})))
    return added,changed,removed

def status(db):
    sources=[]
    for f in feeds():
        row=db.execute("SELECT * FROM sync_runs WHERE board=? ORDER BY id DESC LIMIT 1",(f["board"],)).fetchone()
        latest=dict(row) if row else None
        success=db.execute("SELECT finished_at FROM sync_runs WHERE board=? AND status='ok' ORDER BY id DESC LIMIT 1",(f["board"],)).fetchone()
        count=db.execute("SELECT count(*) FROM collected_jobs WHERE board=?",(f["board"],)).fetchone()[0]
        sources.append(dict(name=f["name"],board=f["board"],sector=f["sector"],coverage=f.get("coverage","Worldwide; restrictions apply"),enabled=f["enabled"],latest=latest,count=count,
            last_success=success[0] if success else None,
            next_due=(app.instant(latest["finished_at"])+app.timedelta(hours=INTERVAL_HOURS)).isoformat() if latest else None))
    return dict(enabled=bool(db.execute("SELECT enabled FROM sync_settings WHERE id=1").fetchone()[0]),
        interval_hours=INTERVAL_HOURS,sources=sources,
        total_collected=db.execute("SELECT count(*) FROM collected_jobs").fetchone()[0])

def run(path=app.DB,due=False,fetcher=fetch,at=None,selected=None):
    configured=feeds()
    if selected and not set(selected)<={f["board"] for f in configured}:
        raise ValueError("Unknown source selection")
    app.initialize(path)
    stamp=(at or app.now()).isoformat()
    owner=str(uuid.uuid4())
    with closing(app.connect(path)) as db:
        db.execute("BEGIN IMMEDIATE")
        if not db.execute("SELECT enabled FROM sync_settings WHERE id=1").fetchone()[0]:
            db.rollback(); return {"status":"paused","results":[]}
        lock=db.execute("SELECT * FROM sync_lock WHERE id=1").fetchone()
        if lock and app.instant(lock["expires_at"])>app.instant(stamp):
            db.rollback(); return {"status":"already_running","results":[]}
        db.execute("INSERT OR REPLACE INTO sync_lock VALUES(1,?,?)",(owner,(app.instant(stamp)+app.timedelta(minutes=15)).isoformat()))
        db.commit()
        results=[]
        try:
            for f in configured:
                if selected and f["board"] not in selected:continue
                if not f["enabled"]: continue
                last=db.execute("SELECT finished_at FROM sync_runs WHERE board=? ORDER BY id DESC LIMIT 1",(f["board"],)).fetchone()
                if due and last and app.instant(stamp)-app.instant(last[0])<app.timedelta(hours=INTERVAL_HOURS): continue
                start=stamp if at else app.now().isoformat()
                # Renew between bounded source runs; each HTML adapter has a six-minute cap.
                db.execute("UPDATE sync_lock SET expires_at=? WHERE id=1 AND owner=?",
                    ((app.instant(start)+app.timedelta(minutes=15)).isoformat(),owner));db.commit()
                try:
                    payload=fetcher(f["board"])
                    rows,total=normalized(payload,f["board"])
                    complete=payload.get("complete",True)
                    if type(complete) is not bool or (not complete and (f["board"] not in ({"unicef"} | set(public_feeds.SMART)) or not payload.get("partial_reason"))):
                        raise ValueError("Invalid partial collection")
                    observed=stamp if at else app.now().isoformat()
                    a,c,r=apply_snapshot(db,f,rows,observed,complete=complete)
                    result=dict(board=f["board"],status="ok" if complete else "partial",fetched=total,added=a,changed=c,removed=r,error=None if complete else "Partial coverage; unseen jobs preserved. "+payload["partial_reason"])
                except Exception as e:
                    db.rollback()
                    result=dict(board=f["board"],status="error",fetched=0,added=0,changed=0,removed=0,error=f"{type(e).__name__}: {str(e)[:300]}")
                finish=stamp if at else app.now().isoformat()
                db.execute("""INSERT INTO sync_runs(board,started_at,finished_at,status,fetched,added,changed,removed,error)
                    VALUES(?,?,?,?,?,?,?,?,?)""",(f["board"],start,finish,result["status"],result["fetched"],result["added"],result["changed"],result["removed"],result["error"]))
                db.commit(); results.append(result)
        finally:
            db.execute("DELETE FROM sync_lock WHERE id=1 AND owner=?",(owner,));db.commit()
        return {"status":"partial_failure" if any(r["status"]!="ok" for r in results) else "ok","results":results}

def background(path,stop):
    while not stop.is_set():
        try: run(path,due=True)
        except Exception as e: print("Automatic update error:",type(e).__name__,flush=True)
        stop.wait(60)

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--due",action="store_true",help="Fetch only if six hours elapsed")
    parser.add_argument("--source",action="append",choices=[f["board"] for f in feeds()],help="Repair only this configured source; repeat for multiple sources")
    args=parser.parse_args()
    report=run(due=args.due,selected=args.source)
    print(json.dumps(report,indent=2))
    raise SystemExit(1 if report["status"]=="partial_failure" else 0)
