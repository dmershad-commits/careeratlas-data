"""Shared data utilities for the public-source collector. No HTTP server or account routes."""
import sqlite3
from contextlib import closing
from datetime import datetime, timezone, timedelta
from pathlib import Path
import facets
ROOT=Path(__file__).resolve().parent
DB=ROOT/"data/atlas.sqlite3"
def now():
    return datetime.now(timezone.utc)
def instant(value):
    result=datetime.fromisoformat(value.replace("Z","+00:00"))
    if result.tzinfo is None: raise ValueError("Timezone required")
    return result
def connect(path=DB):
    db=sqlite3.connect(path)
    db.row_factory=sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    return db
def initialize(path=DB):
    with closing(connect(path)) as db:
        db.executescript((ROOT/"schema.sql").read_text(encoding="utf-8"))
        db.commit()
def list_jobs(db):
    result=[]
    query="""SELECT j.*,o.name organization,o.sector,s.url source_url,s.attribution
      FROM jobs j JOIN sources s ON s.id=j.source_id
      JOIN organizations o ON o.id=s.organization_id WHERE j.is_demo=0"""
    for row in db.execute(query):
        j=dict(row)
        c=db.execute("SELECT * FROM collected_jobs WHERE job_id=?",(j["id"],)).fetchone()
        if not c: continue
        c=dict(c)
        original=c.pop("description","")
        summary=original[9:] if original.startswith("Summary: ") else f"{j['title']} at {j['organization']}. Location: {j['location']}. Work arrangement: {j['work_mode']}. Read the original vacancy for duties, eligibility and application instructions."
        c["summary"]=" ".join(summary.split())[:700]
        j["collection"]=c
        j["salary"]=None
        j.update(facets.classify(j))
        result.append(j)
    return sorted(result,key=lambda j:(j["deadline"] is None,j["deadline"] or "",j["id"]))
