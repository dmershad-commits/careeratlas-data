"""Reviewed public feeds. Brief facts and source links, no application actions."""
import json
import os
import re
from urllib.parse import urlencode,urlsplit
from source_adapters import Reader,Tree,record,PartialListing

SMART={"snv":"SNV","sf-government":"CityAndCountyOfSanFrancisco1","bosch":"BoschGroup","cern":"CERN","oecd":"OECD","sgs":"SGS","ubisoft":"Ubisoft2","abbvie":"AbbVie","eurofins":"Eurofins","expeditors":"Expeditors","hmgroup":"HMGroup","continental":"Continental","interikea":"InterIKEAGroup"}
BASES={k:f"https://api.smartrecruiters.com/v1/companies/{v}/postings" for k,v in SMART.items()}
BASES.update({"unu":"https://careers.unu.edu/","reliefweb":"https://api.reliefweb.int/v2/jobs"})

def nonvacancy(title):
    return bool(re.search(r"\broster\b|\btalent (?:pool|community)\b|\bexpression of interest\b|\brequest for proposals?\b|\btender\b|bureau d[’']études",title,re.I))

def smart_page(payload,company,offset):
    if not isinstance(payload,dict) or payload.get("offset")!=offset or type(payload.get("totalFound")) is not int or not isinstance(payload.get("content"),list):
        raise ValueError("Invalid public postings page")
    rows=[];ids=[]
    for j in payload["content"]:
        id=j.get("id");title=j.get("name")
        if not isinstance(id,str) or not id.isdigit() or not title or j.get("company",{}).get("identifier","").lower()!=company.lower():
            raise ValueError("Invalid public posting identity")
        if j.get("visibility")!="PUBLIC":raise ValueError("Nonpublic posting rejected")
        if j.get("ref")!=f"https://api.smartrecruiters.com/v1/companies/{company}/postings/{id}":
            raise ValueError("Unexpected posting reference")
        ids.append(id)
        if nonvacancy(title):continue
        loc=j.get("location") or {}
        location=loc.get("fullLocation") or ", ".join(str(loc[k]) for k in ("city","region","country") if loc.get(k)) or "Not stated"
        details=[]
        for key,label in (("typeOfEmployment","Contract"),("department","Department"),("experienceLevel","Experience category")):
            if j.get(key,{}).get("label"):details.append(label+": "+j[key]["label"])
        from app import instant
        posted=instant(j["releasedDate"]).date().isoformat() if j.get("releasedDate") else None
        row=record(id,title,location,f"https://jobs.smartrecruiters.com/{company}/{id}",
            "Summary: "+title+". "+location+". "+". ".join(details)+". See the original notice for requirements and application instructions.",posted=posted)
        row["work_mode"]="hybrid" if loc.get("hybrid") is True else "remote" if loc.get("remote") is True else "unknown"
        rows.append(row)
    if len(ids)!=len(set(ids)):raise ValueError("Repeated public posting")
    return rows,ids,payload["totalFound"]

def collect_smart(reader,company):
    offset=0;seen=set();rows={};expected=None;moving=False
    for _ in range(150):
        batch,ids,total=smart_page(json.loads(reader.get(reader.base+f"?limit=100&offset={offset}")),company,offset)
        if expected is None:expected=total
        if total!=expected or seen.intersection(ids):moving=True
        for row in batch:
            # Keep the latest observed version; all records passed public/schema checks.
            rows[row["external_id"]]=row
        seen.update(ids);offset+=len(ids)
        if offset>=total or not ids:
            if moving or len(seen)!=total or offset!=total:
                if not rows:raise ValueError("Empty inconsistent public postings snapshot")
                raise PartialListing(list(rows.values()),"Public postings changed during pagination; only observed vacancies refreshed")
            return list(rows.values())
    raise ValueError("Public postings page limit exceeded")

def unu_page(text):
    if "</html>" not in text.lower():raise ValueError("Truncated UNU page")
    tree=Tree(text).root
    configs=[]
    for node in tree.find("div"):
        value=node.attrs.get("data-props","")
        if value.startswith('{"appConfig":'):configs.append(json.loads(value)["appConfig"])
    if len(configs)!=1 or not isinstance(configs[0].get("offers"),list):
        raise ValueError("UNU public offers state missing")
    offers=configs[0]["offers"];rows=[];ids=set()
    visible={a.attrs.get("href","").split("?")[0] for a in tree.find("a") if a.attrs.get("href","").startswith("/o/")}
    for j in offers:
        if type(j.get("id")) is not int or j["id"] in ids or j.get("status")!="published":
            raise ValueError("Invalid UNU public offer")
        ids.add(j["id"])
        slug=j.get("slug","")
        if not re.fullmatch("[a-zA-Z0-9-]+",slug) or "/o/"+slug not in visible:raise ValueError("UNU offer not linked on public page")
        tr=j["translations"][j["primaryLangCode"]];title=tr["title"]
        if nonvacancy(title):continue
        location=", ".join(x for x in (j.get("city"),tr.get("country")) if x) or "Not stated"
        details=f"Contract: {j.get('employmentType') or 'not stated'}. Experience category: {j.get('experience') or 'not stated'}."
        row=record(j["id"],title,location,"https://careers.unu.edu/o/"+slug,
            "Summary: "+title+". "+location+". "+details+" Check the original notice for full criteria, closing date and application instructions.")
        row["work_mode"]="hybrid" if j.get("hybrid") is True else "remote" if j.get("remote") is True else "onsite" if j.get("onSite") is True else "unknown"
        rows.append(row)
    if not offers:raise ValueError("Empty UNU page needs review")
    if visible!={"/o/"+j["slug"] for j in offers}:raise ValueError("UNU linked offers and embedded list disagree")
    return rows

def relief_page(payload):
    if not isinstance(payload.get("data"),list) or type(payload.get("totalCount")) is not int:
        raise ValueError("Invalid ReliefWeb response")
    rows=[]
    from app import instant
    for item in payload["data"]:
        f=item["fields"];id=str(item["id"]);url=f.get("url_alias") or f.get("url","")
        if not id.isdigit() or urlsplit(url).hostname!="reliefweb.int" or urlsplit(url).scheme!="https" or not urlsplit(url).path.startswith("/job/"):
            raise ValueError("Unexpected ReliefWeb notice URL")
        employer=", ".join(x["name"] for x in f.get("source",[])) or "Employer in original notice"
        location=", ".join(x["name"] for x in f.get("city",[])+f.get("country",[])) or "Not stated"
        date=f.get("date",{});deadline=instant(date["closing"]).isoformat() if date.get("closing") else None
        rows.append(record(id,f["title"]+" — "+employer,location,url,
            "Summary: "+f["title"]+". Employer: "+employer+". Location: "+location+". Listed via ReliefWeb; open its notice for the employer's application instructions.",
            deadline,date.get("closing"),instant(date["created"]).date().isoformat() if date.get("created") else None))
    return rows,payload["totalCount"]

def collect_relief(reader,appname):
    if not appname:raise ValueError("ReliefWeb requires a pre-approved RELIEFWEB_APPNAME")
    from app import now
    base=[("appname",appname),("limit","1000"),("sort[]","id:asc"),("filter[field]","date.closing"),("filter[value][from]",now().date().isoformat()+"T00:00:00+00:00")]
    base += [("fields[include][]",x) for x in ("title","source","city","country","date","url","url_alias")]
    rows=[];seen=set();expected=None
    for offset in range(0,10000,1000):
        batch,total=relief_page(json.loads(reader.get(reader.base+"?"+urlencode(base+[("offset",str(offset))]))))
        if expected is None:expected=total
        if total!=expected:raise ValueError("ReliefWeb total changed")
        for row in batch:
            if row["external_id"] in seen:raise ValueError("Repeated ReliefWeb notice")
            seen.add(row["external_id"])
        rows.extend(batch)
        if len(rows)==expected:return rows
        if len(batch)!=1000 or len(rows)>expected:raise ValueError("Incomplete ReliefWeb snapshot")
    raise ValueError("ReliefWeb limit exceeded")

def collect(board):
    if board=="reliefweb" and not os.environ.get("RELIEFWEB_APPNAME"):
        raise ValueError("ReliefWeb disabled pending pre-approved app name")
    reader=Reader(BASES[board])
    # Documented data APIs are consumed under their API contract, not indexed as
    # HTML by a web crawler. No credentials are sent; INTERNAL records are rejected.
    # https://developers.smartrecruiters.com/docs/posting-api
    # https://apidoc.reliefweb.int/
    if board=="unu":reader.check_robots()
    if board in SMART:
        try:rows=collect_smart(reader,SMART[board])
        except PartialListing as e:
            return {"atlas_rows":e.rows,"total":len(e.rows),"complete":False,"partial_reason":e.reason}
    elif board=="unu":rows=unu_page(reader.get(reader.base))
    else:rows=collect_relief(reader,os.environ["RELIEFWEB_APPNAME"])
    return {"atlas_rows":rows,"total":len(rows),"complete":True}
