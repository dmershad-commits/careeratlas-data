"""Bounded readers for reviewed official public vacancy listings.

HTML readers use only public listing/detail URLs, never login/application actions.
Summary-only sources are labelled; ambiguous dates do not become exact deadlines.
"""
import json
import re
import time
from datetime import datetime
from html.parser import HTMLParser
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin,urlsplit,parse_qs,quote
from urllib.request import Request,build_opener,HTTPRedirectHandler
from urllib.robotparser import RobotFileParser

PAGES={
 "unicef":"https://jobs.unicef.org/en-us/listing/",
 "unops":"https://careers.unops.org/careersmarketplace/SearchJobs",
 "icddrb":"https://career.icddrb.org/",
 "ny-state":"https://statejobs.ny.gov/public/vacancyTable.cfm",
 "unfpa":"https://www.unfpa.org/jobs",
 "unesco":"https://careers.unesco.org/go/All-jobs/782502/",
 "bd-teletalk":"https://alljobs.teletalk.com.bd/jobs/government",
}
MAX_BYTES=15_000_000
class SourceChallenge(ValueError):
    pass

class PartialListing(Exception):
    def __init__(self,rows,reason):
        self.rows=rows;self.reason=reason

class RejectRedirect(HTTPRedirectHandler):
    def redirect_request(self,*a,**kw):raise ValueError("Unexpected source redirect; review required")

class Reader:
    def __init__(self,base):
        self.base=base;self.host=urlsplit(base).hostname
        self.opener=build_opener(RejectRedirect);self.started=time.monotonic()
        self.robots=None
    def get(self,url,robots=False):
        u=urlsplit(url)
        if u.scheme!="https" or u.hostname!=self.host or u.username:
            raise ValueError("Unapproved source URL")
        if time.monotonic()-self.started>360:raise ValueError("Source collection time limit exceeded")
        if not robots and self.robots and not self.robots.can_fetch("AtlasPrivateJobs",url):
            raise ValueError("Source robots policy disallows listing")
        time.sleep(0.35)
        request=Request(quote(url,safe=":/?=&%+-._~"),headers={"User-Agent":"AtlasPrivateJobs/4.0 (private vacancy reader)"})
        for attempt in range(3):
            if time.monotonic()-self.started>360:raise ValueError("Source collection time limit exceeded")
            try:
                with self.opener.open(request,timeout=25) as r:
                    if r.headers.get("x-amzn-waf-action")=="challenge":
                        raise SourceChallenge("Official source requires an access challenge at "+url)
                    raw=r.read(MAX_BYTES+1)
                    if len(raw)>MAX_BYTES:raise ValueError("Source size limit exceeded")
                    charset=r.headers.get_content_charset() or "utf-8"
                    text=raw.decode(charset,errors="replace")
                    # Some public listing pages intermittently return HTTP 200 with no body.
                    # Retry the identical read; never accept an empty vacancy snapshot.
                    if text.strip() or robots:return text
                    if attempt==2:raise ValueError("Empty source response after three reads: "+url)
            except HTTPError as e:
                if e.code not in (429,500,502,503,504) or attempt==2:raise
                retry=e.headers.get("Retry-After","")
                if retry and (not retry.isdigit() or int(retry)>10):raise
                if retry:time.sleep(int(retry))
            except (URLError,TimeoutError):
                if attempt==2:raise
            time.sleep(2*(attempt+1))
    def check_robots(self):
        url=f"https://{self.host}/robots.txt"
        try:text=self.get(url,robots=True)
        except HTTPError as e:
            if e.code==404:return
            raise
        rules=RobotFileParser();rules.parse(text.lstrip("\ufeff").splitlines());self.robots=rules
        if not rules.can_fetch("AtlasPrivateJobs",self.base):raise ValueError("Robots policy disallows collection")

class Node:
    def __init__(self,tag="",attrs=None,parent=None):
        self.tag=tag;self.attrs=dict(attrs or []);self.children=[];self.parent=parent
    def text(self):
        return " ".join(" ".join(c if isinstance(c,str) else c.text() for c in self.children).split())
    def find(self,tag=None,cls=None):
        found=[]
        for c in self.children:
            if not isinstance(c,Node):continue
            if (not tag or c.tag==tag) and (not cls or cls in c.attrs.get("class","").split()):found.append(c)
            found.extend(c.find(tag,cls))
        return found

class Tree(HTMLParser):
    def __init__(self,text):
        super().__init__(convert_charrefs=True);self.root=Node();self.stack=[self.root];self.feed(text)
    def handle_starttag(self,tag,attrs):
        node=Node(tag,attrs,self.stack[-1]);self.stack[-1].children.append(node)
        if tag not in ("area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr"):
            self.stack.append(node)
    def handle_endtag(self,tag):
        for i in range(len(self.stack)-1,0,-1):
            if self.stack[i].tag==tag:self.stack=self.stack[:i];break
    def handle_data(self,data):
        if not any(n.tag in ("script","style") for n in self.stack):
            self.stack[-1].children.append(data)

def mode(text):
    if re.search(r"\b(?:remote|remotely|home[- ]based)\b",text,re.I):return "remote"
    if re.search(r"\bhybrid\b",text,re.I):return "hybrid"
    return "unknown"

def date_only(text,fmt):
    try:return datetime.strptime(" ".join(text.split()),fmt).date().isoformat()
    except ValueError:return None

def record(id,title,location,url,description,deadline=None,raw=None,posted=None):
    return dict(external_id=str(id),title=title,location=location,url=url,
        work_mode=mode(location+" "+title),posted_on=posted,deadline=deadline,
        deadline_raw=raw or "Not stated; consult official notice",
        description=description,source_updated_at=None)

def unicef_page(text,base):
    if "</html>" not in text.lower():raise ValueError("Truncated UNICEF response")
    tree=Tree(text).root;out={}
    for node in tree.find(cls="list-view--item"):
        links=node.find("a",cls="job-link")
        if not links:continue
        a=links[0];url=urljoin(base,a.attrs.get("href",""))
        m=re.fullmatch(r"https://jobs\.unicef\.org/(?:cw/)?en-us/job/(\d+)/.+",url)
        if not m:raise ValueError("Unexpected UNICEF vacancy URL")
        loc=node.find(cls="location");times=node.find("time")
        if not loc or not times:raise ValueError("UNICEF listing fields missing")
        deadline=times[0].attrs.get("datetime")
        if not deadline:raise ValueError("UNICEF deadline missing")
        from app import instant
        deadline=instant(deadline).isoformat()
        teaser=node.find(cls="row--teaser")
        description="Official listing summary (full requirements at source):\n"+(teaser[0].text() if teaser else node.text())
        j=record(m[1],a.text(),loc[0].text(),url,description,deadline,times[0].text())
        if m[1] in out and out[m[1]]!=j:raise ValueError("Conflicting duplicated UNICEF entry")
        out[m[1]]=j
    more=tree.find("a",cls="more-link")
    next_url=urljoin(base,more[0].attrs["href"]) if more else None
    remaining=int(more[0].find(cls="count")[0].text()) if more else 0
    if not out:raise ValueError("UNICEF listing empty or changed; manual review required")
    return list(out.values()),next_url,remaining

def collect_unicef(reader):
    url=reader.base;seen_urls=set();rows={};expected=None
    for page in range(40):
        if url in seen_urls:raise ValueError("Repeated pagination URL")
        seen_urls.add(url)
        try:text=reader.get(url)
        except SourceChallenge as e:
            if rows:raise PartialListing(list(rows.values()),str(e))
            raise
        current,next_url,remaining=unicef_page(text,reader.base)
        if expected is None:expected=len(current)+remaining
        for j in current:
            if j["external_id"] in rows:raise ValueError("Pagination repeated a vacancy")
            rows[j["external_id"]]=j
        if len(rows)+remaining!=expected:raise ValueError("Listing changed during pagination; retry next run")
        if not next_url:
            if len(rows)!=expected:raise ValueError("Incomplete UNICEF listing")
            return list(rows.values())
        u=urlsplit(next_url)
        if u.hostname!=reader.host or u.path not in ("/en-us/listing/","/cw/en-us/listing/"):raise ValueError("Unexpected pagination destination")
        url=next_url
    raise ValueError("UNICEF pagination limit exceeded")

def unops_page(text,base):
    if "</html>" not in text.lower():raise ValueError("Truncated UNOPS response")
    tree=Tree(text).root
    counters=tree.find(cls="list-controls__text__legend")
    total_match=re.search(r"\bof\s+(\d+)\s+results\b",tree.text())
    if not total_match:raise ValueError("UNOPS result total missing")
    out=[]
    for article in tree.find("article"):
        anchors=[a for a in article.find("a") if "/careersmarketplace/JobDetail/" in a.attrs.get("href","")]
        if not anchors:continue
        a=anchors[0];url=a.attrs["href"]
        if urlsplit(url).hostname!="careers.unops.org":raise ValueError("Unexpected UNOPS link")
        loc=[n for n in article.find("span") if n.attrs.get("class")=="list-item-Duty Station"]
        content=article.find(cls="article__content")
        dates=article.find("span",cls="list-item-posted")
        # The listing class does not establish whether its date means posted or closing.
        note="Listing date (meaning requires source review): "+dates[0].text() if dates else "No confirmed deadline"
        out.append(record(url.rstrip("/").rsplit("/",1)[1],a.text(),loc[0].text() if loc else "Not stated",
            url,"Official listing summary (full requirements at source):\n"+(content[0].text() if content else a.text())+"\n"+note))
    next_links=[a for a in tree.find("a") if a.attrs.get("aria-label","").startswith("Go to Next Page")]
    return out,next_links[0].attrs["href"] if next_links else None,int(total_match[1])

def collect_unops(reader):
    rows={};url=reader.base;seen=set();expected=None
    for page in range(50):
        if url in seen:raise ValueError("Repeated UNOPS page")
        seen.add(url)
        batch,next_url,total=unops_page(reader.get(url),reader.base)
        if expected is None:expected=total
        if expected!=total:raise ValueError("UNOPS total changed during pagination")
        for j in batch:
            if j["external_id"] in rows:raise ValueError("Repeated UNOPS record")
            rows[j["external_id"]]=j
        if not next_url:
            if len(rows)!=expected:raise ValueError("Incomplete UNOPS listing")
            return list(rows.values())
        u=urlsplit(next_url)
        if u.hostname!=reader.host or not u.path.startswith("/careersmarketplace/SearchJobs"):raise ValueError("Unexpected UNOPS page URL")
        url=next_url
    raise ValueError("UNOPS pagination limit exceeded")

def icddrb_page(text,base):
    if "</html>" not in text.lower():raise ValueError("Truncated icddr,b response")
    tree=Tree(text).root;tables=tree.find("tbody",cls="current-opportunities")
    if len(tables)!=1:raise ValueError("icddr,b listing marker changed")
    out=[]
    for tr in tables[0].find("tr"):
        cells=tr.find("td");anchors=tr.find("a")
        if not anchors:continue
        url=anchors[0].attrs["href"]
        if not re.fullmatch(r"https://career\.icddrb\.org/vacancy-preview/\d+",url) or len(cells)!=3:
            raise ValueError("icddr,b row schema changed")
        posted=re.search(r"Posted on:\s*(.*)",cells[0].text())
        out.append(record(url.rsplit("/",1)[1],anchors[0].text(),"Bangladesh — duty station in official notice",url,
            "Official listing summary; consult the notice for full eligibility, location and salary.\n"+tr.text(),
            raw=cells[2].text(),posted=date_only(posted[1],"%B %d, %Y") if posted else None))
    if not out:raise ValueError("Empty icddr,b listing requires manual review")
    return out

def ny_page(text,base):
    if "</html>" not in text.lower() or "Current Vacancies" not in text:
        raise ValueError("NY listing unavailable or truncated")
    tree=Tree(text).root;out=[]
    for tr in tree.find("tr"):
        cells=tr.find("td")
        anchors=[a for a in tr.find("a") if "vacancyDetailsView.cfm?id=" in a.attrs.get("href","")]
        if not anchors:continue
        if len(cells)!=7:raise ValueError("NY table schema changed")
        url=urljoin(base,anchors[0].attrs["href"])
        if urlsplit(url).hostname!="statejobs.ny.gov":raise ValueError("Unexpected NY link")
        id=parse_qs(urlsplit(url).query)["id"][0]
        description=f"Official listing summary. Agency: {cells[5].text()}. Grade: {cells[2].text()}. County: {cells[6].text()}. Full requirements and salary are at the official notice."
        out.append(record(id,anchors[0].text(),cells[6].text()+", New York, United States",url,description,
            raw=cells[4].text()+" (date only; closing time not supplied)",posted=date_only(cells[3].text(),"%m/%d/%y")))
    if not out:raise ValueError("Empty NY table requires review")
    return out

def unfpa_page(text,base):
    if "</html>" not in text.lower():raise ValueError("Truncated UNFPA listing")
    views=Tree(text).root.find(cls="view-display-id-jobs_listing")
    if len(views)!=1:raise ValueError("UNFPA current-jobs view missing")
    view=views[0];match=re.search(r"(\d+) results found",view.text())
    if not match:raise ValueError("UNFPA result count missing")
    rows=[]
    for n in view.find(cls="jbs-rows"):
        titles=n.find("h5")
        if len(titles)!=1 or len(titles[0].find("a"))!=1:raise ValueError("UNFPA title changed")
        a=titles[0].find("a")[0];url=a.attrs["href"]
        if not url.startswith("https://www.unfpa.org/jobs/"):raise ValueError("Unexpected UNFPA job URL")
        fields={}
        for group in n.find(cls="form-group"):
            labels=group.find("label");values=group.find("p")
            if labels and values:fields[labels[0].text()]=values[0].text()
        if not fields.get("Location") or not fields.get("Closing date"):raise ValueError("UNFPA fields missing")
        raw=fields["Closing date"];deadline=None
        # Preserve IANA zone evidence. Only normalize when system timezone data exists.
        m=re.fullmatch(r"(.+)\(([^)]+)\)",raw)
        if m:
            from zoneinfo import ZoneInfo,ZoneInfoNotFoundError
            try:deadline=datetime.strptime(m[1].strip(),"%d %B %Y %H:%M").replace(tzinfo=ZoneInfo(m[2])).isoformat()
            except ZoneInfoNotFoundError:pass
        rows.append(record(url.rsplit("/",1)[1],a.text(),fields["Location"],url,
            "Official current vacancy listing summary. Full requirements at source.\n"+
            "\n".join(k+": "+v for k,v in fields.items()),deadline,raw))
    nxt=[a for a in view.find("a") if a.attrs.get("rel")=="next"]
    return rows,urljoin(base,nxt[0].attrs["href"]) if nxt else None,int(match[1])

def unesco_page(text,base):
    if "</html>" not in text.lower():raise ValueError("Truncated UNESCO listing")
    tree=Tree(text).root
    labels=tree.find(cls="paginationLabel")
    m=re.search(r"Results\s+(\d+)\D+(\d+)\s+of\s+(\d+)",labels[0].text() if labels else "")
    if not m:raise ValueError("UNESCO total missing")
    rows=[]
    for n in tree.find("tr",cls="data-row"):
        links=n.find("a",cls="jobTitle-link");loc=n.find("td",cls="colLocation")
        dates=n.find(cls="jobShifttype")
        if not links or not loc or not dates:raise ValueError("UNESCO row schema changed")
        url=urljoin(base,links[0].attrs["href"])
        id=re.fullmatch(r"https://careers\.unesco\.org/job/[^/]+/(\d+)/",url)
        if not id:raise ValueError("Unexpected UNESCO vacancy URL")
        rows.append(record(id[1],links[0].text(),loc[0].text(),url,
            "Official listing summary; consult vacancy for full requirements.\n"+n.text(),
            raw=dates[0].text()+" (date only; closing time not supplied)"))
    start,end,total=map(int,m.groups())
    if len(rows)!=end-start+1:raise ValueError("UNESCO page count mismatch")
    next_url=None
    if end<total:
        current=(start-1)//25+1
        links=[a for a in tree.find("a") if a.attrs.get("title")==f"Page {current+1}"]
        if not links:raise ValueError("UNESCO next page missing")
        next_url=urljoin(base,links[0].attrs["href"])
    return rows,next_url,total

def collect_counted(reader,parser):
    url=reader.base;seen=set();rows={};expected=None
    for _ in range(80):
        if url in seen:raise ValueError("Repeated pagination URL")
        seen.add(url);batch,nxt,total=parser(reader.get(url),reader.base)
        if expected is None:expected=total
        if total!=expected:raise ValueError("Total changed during pagination")
        for row in batch:
            if row["external_id"] in rows:raise ValueError("Repeated vacancy across pages")
            rows[row["external_id"]]=row
        if not nxt:
            if len(rows)!=expected:raise ValueError("Incomplete official listing")
            return list(rows.values())
        u=urlsplit(nxt)
        if u.scheme!="https" or u.hostname!=reader.host:raise ValueError("Unexpected pagination URL")
        url=nxt
    raise ValueError("Pagination limit exceeded")

def tele_response(text,key):
    p=json.loads(text)
    if p.get("status")!="success" or p.get("statusCode")!=200 or type(p.get("count")) is not int or not isinstance(p.get(key),list):
        raise ValueError("Teletalk response schema changed")
    return p[key],p["count"]

def collect_teletalk(reader):
    organizations={};expected=None
    for page in range(1,101):
        batch,total=tele_response(reader.get(f"https://{reader.host}/api/v1/govt-jobs/org-list?page={page}&limit=20"),"govtOrgJobs")
        if expected is None:expected=total
        if total!=expected:raise ValueError("Government organization count changed")
        for org in batch:
            if type(org.get("id")) is not int or org["id"] in organizations or not org.get("name") or not isinstance(org.get("govt_jobs"),list):
                raise ValueError("Invalid or repeated government organization")
            organizations[org["id"]]=org
        if len(organizations)==expected:break
        if not batch or len(organizations)>expected:raise ValueError("Incomplete government organizations")
    else:raise ValueError("Government organization pagination limit")
    from app import instant
    out=[]
    for oid,org in organizations.items():
        batch,total=tele_response(reader.get(f"https://{reader.host}/api/v1/govt-jobs/list?orgId={oid}&skipLimit=YES"),"govtJobs")
        ids=[j.get("id") for j in batch]
        if len(batch)!=total or len(set(ids))!=len(ids) or set(ids)!={j["id"] for j in org["govt_jobs"]}:
            raise ValueError("Government vacancies changed or incomplete; retry next run")
        for j in batch:
            if type(j.get("id")) is not int or j.get("organization_id")!=oid or not j.get("job_title"):
                raise ValueError("Invalid government vacancy")
            deadline=instant(j["deadline_date"]).isoformat() if j.get("deadline_date") else None
            raw=j.get("deadline_date") or "Not stated"
            summary=f"Employer: {org['name']}\nOfficial Teletalk listing; consult linked notice for eligibility and salary.\n"
            summary+=f"Bangla title: {j.get('job_title_bn') or ''}\nPosts: {j.get('vacancy') or 'Not stated'}\nSource published/opening date: {j.get('published_date') or 'Not stated'}"
            out.append(record(j["id"],j["job_title"]+" — "+org["name"],"Bangladesh — duty station in official notice",
                f"https://{reader.host}/jobs/government/{oid}?jobId={j['id']}",summary,deadline,raw))
    return out

def collect(board):
    reader=Reader(PAGES[board]);reader.check_robots()
    complete=True;reason=None
    if board=="unicef":
        try:rows=collect_unicef(reader)
        except PartialListing as e:rows=e.rows;reason=e.reason;complete=False
    elif board=="unops":rows=collect_unops(reader)
    elif board=="icddrb":rows=icddrb_page(reader.get(reader.base),reader.base)
    elif board=="ny-state":rows=ny_page(reader.get(reader.base),reader.base)
    elif board=="unfpa":rows=collect_counted(reader,unfpa_page)
    elif board=="unesco":rows=collect_counted(reader,unesco_page)
    elif board=="bd-teletalk":rows=collect_teletalk(reader)
    else:raise ValueError("Unknown reviewed source")
    ids=[j["external_id"] for j in rows]
    if len(ids)!=len(set(ids)):raise ValueError("Duplicate source IDs")
    return {"atlas_rows":rows,"total":len(rows),"complete":complete,"partial_reason":reason}
