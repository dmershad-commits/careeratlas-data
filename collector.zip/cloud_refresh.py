"""GitHub-hosted entrypoint: collect, validate, publish summaries, retain state in cache."""
import gzip
import json
import os
import sqlite3
from contextlib import closing
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/"collector"))
import updater
import app
from export_public import export

TABLES=("organizations","sources","jobs","collected_jobs","sync_runs")

def restore_state():
    state=ROOT/"public/state.json.gz"
    if app.DB.exists() or not state.exists():
        return
    data=json.loads(gzip.decompress(state.read_bytes()))
    app.initialize(app.DB)
    with closing(app.connect(app.DB)) as db:
        for table in TABLES:
            for row in data[table]:
                allowed={c[1] for c in db.execute(f"PRAGMA table_info({table})")}
                if set(row)-allowed:
                    raise ValueError("Unexpected state columns")
                keys=list(row)
                db.execute(f"INSERT INTO {table} ({','.join(keys)}) VALUES ({','.join('?' for _ in keys)})",
                           [row[k] for k in keys])
        db.commit()

def write_state(public):
    state={}
    with closing(app.connect(app.DB)) as db:
        for table in TABLES:
            query=f"SELECT * FROM {table}"
            if table=="sync_runs":
                query+=" WHERE id IN (SELECT max(id) FROM sync_runs GROUP BY board)"
            rows=[dict(r) for r in db.execute(query)]
            for row in rows:
                if table=="sources":
                    row["notes"]=""
                if table=="collected_jobs":
                    # Keep freshness and identity; never publish full copied descriptions.
                    row["description"]=""
                if table=="sync_runs":
                    row["error"]=None
            state[table]=rows
    (public/"state.json.gz").write_bytes(gzip.compress(
        json.dumps(state,ensure_ascii=False,separators=(",",":")).encode(),mtime=0))

def main():
    restore_state()
    report=updater.run()
    successes=[r for r in report["results"] if r["status"] in ("ok","partial")]
    if not successes:
        raise RuntimeError("No source succeeded; keep the previous public catalogue.")
    data=export()
    # Reject unsafe/accidentally empty exports before touching the public output.
    if len(data["jobs"])<1000:
        raise RuntimeError("Catalogue is unexpectedly small; publication blocked.")
    if any(not j["url"].startswith("https://") for j in data["jobs"]):
        raise RuntimeError("Non-HTTPS application link rejected.")
    public=ROOT/"public"
    public.mkdir(exist_ok=True)
    packed=gzip.compress(json.dumps(data,ensure_ascii=False,separators=(",",":")).encode(),mtime=0)
    tmp=public/"jobs.tmp"
    tmp.write_bytes(packed)
    tmp.replace(public/"jobs.json.gz")
    write_state(public)
    status={"generated_at":data["generated_at"],"jobs":len(data["jobs"]),
            "successful_sources":len(successes),"total_sources":len(report["results"]),
            "partial_sources":[r["board"] for r in report["results"] if r["status"]=="partial"],
            "failed_sources":[r["board"] for r in report["results"] if r["status"]=="error"],
            "run_url":f"https://github.com/{os.environ.get('GITHUB_REPOSITORY','')}/actions/runs/{os.environ.get('GITHUB_RUN_ID','')}"}
    (public/"status.json").write_text(json.dumps(status,indent=2),encoding="utf-8")
    print(json.dumps(report,indent=2))
    print(json.dumps(status,indent=2))

if __name__=="__main__":
    main()
