"""Build the public, read-only catalogue; never export account or review data."""
import json
import sys
from pathlib import Path
from urllib.parse import urlsplit
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "collector"))
import app
import updater

def safe_url(value):
    parsed = urlsplit(value or "")
    return value if parsed.scheme == "https" and parsed.hostname and not parsed.username else None

def export():
    with app.connect() as db:
        jobs = []
        for job in app.list_jobs(db):
            collected = job["collection"]
            if not collected or job["is_demo"] or not safe_url(job["url"]):
                continue
            public = {k: job[k] for k in (
                "id", "title", "organization", "sector", "location", "work_mode",
                "url", "posted_on", "deadline", "closed", "career_level", "countries", "industry")}
            public.update(summary=collected["summary"], last_seen=collected["last_seen"],
                          first_seen=collected["first_seen"], availability=collected["availability"],
                          attribution=job["attribution"], source_url=safe_url(job["source_url"]),
                          salary=job["salary"])
            # Stable across independent local/cloud databases and cache eviction.
            public["id"]=collected["board"]+":"+str(job["external_id"])
            jobs.append(public)
        sources = []
        for feed in updater.feeds():
            last = db.execute("SELECT status,finished_at,fetched FROM sync_runs WHERE board=? ORDER BY id DESC LIMIT 1", (feed["board"],)).fetchone()
            sources.append(dict(name=feed["name"],url=safe_url(feed["official_url"]),
                enabled=feed["enabled"], last=dict(last) if last else None))
    output = dict(generated_at=app.now().isoformat(), jobs=jobs, sources=sources)
    target = ROOT / "dist/jobs.json"
    temp = target.with_suffix(".tmp")
    temp.write_text(json.dumps(output, ensure_ascii=False, separators=(",",":")), encoding="utf-8")
    temp.replace(target)
    print(f"Exported {len(jobs)} public job summaries.")
    return output

if __name__ == "__main__":
    export()
