import gzip
import json
from pathlib import Path
import tempfile
import unittest
from contextlib import closing
from unittest.mock import patch
import cloud_refresh as cloud

class CloudStateTests(unittest.TestCase):
    def test_state_keeps_freshness_and_excludes_private_or_full_text(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            root=Path(directory)
            assert root.resolve().parent==Path(__file__).resolve().parent
            (root/"public").mkdir()
            dbpath=root/"state.sqlite3"
            cloud.app.initialize(dbpath)
            with closing(cloud.app.connect(dbpath)) as db:
                db.execute("INSERT INTO organizations VALUES(1,'Test employer','Private')")
                db.execute("INSERT INTO sources VALUES(1,1,'https://example.com','confirmed','2026-10-20','Employer','private note')")
                db.execute("INSERT INTO jobs(id,source_id,external_id,title,location,url) VALUES(1,1,'123','Analyst','USA','https://example.com/jobs/123')")
                db.execute("INSERT INTO collected_jobs(job_id,board,description,first_seen,last_seen,content_hash) VALUES(1,'example','FULL PRIVATE DESCRIPTION','2026-10-19T00:00:00+00:00','2026-10-20T00:00:00+00:00','hash')")
                db.execute("INSERT INTO saved_jobs VALUES(1,'2026-10-20')")
                db.commit()
            with patch.object(cloud,"ROOT",root),patch.object(cloud.app,"DB",dbpath):
                cloud.write_state(root/"public")
                state=json.loads(gzip.decompress((root/"public/state.json.gz").read_bytes()))
                self.assertNotIn("saved_jobs",state)
                self.assertEqual(state["sources"][0]["notes"],"")
                self.assertEqual(state["collected_jobs"][0]["description"],"")
                # Simulate a fresh cloud machine with no local database.
                restored=root/"new.sqlite3"
                with patch.object(cloud.app,"DB",restored):
                    cloud.restore_state()
                    with closing(cloud.app.connect(restored)) as db:
                        row=db.execute("SELECT * FROM collected_jobs").fetchone()
                        self.assertEqual(row["last_seen"],"2026-10-20T00:00:00+00:00")
                        self.assertEqual(row["content_hash"],"hash")
                        self.assertEqual(db.execute("SELECT count(*) FROM saved_jobs").fetchone()[0],0)

if __name__=="__main__":
    unittest.main()
